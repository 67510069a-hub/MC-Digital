# MC DIGITAL — Site vitrine

Site vitrine responsive en français, prêt pour GitHub Pages.

## Fichiers
- `index.html` : contenu du site
- `style.css` : design et adaptation mobile
- `script.js` : menu mobile et année automatique

## Publication avec un téléphone
1. Ouvrir https://github.com et se connecter.
2. Appuyer sur **+** puis **New repository**.
3. Nom du dépôt : `mc-digital`. Choisir **Public**, puis **Create repository**.
4. Dans le dépôt, choisir **Add file** puis **Upload files**.
5. Envoyer les trois fichiers `index.html`, `style.css` et `script.js` (décompresser d'abord le ZIP sur le téléphone).
6. Appuyer sur **Commit changes**.
7. Ouvrir **Settings** → **Pages**.
8. Dans **Build and deployment**, choisir **Deploy from a branch**.
9. Choisir la branche **main** et le dossier **/(root)**, puis **Save**.
10. Attendre quelques minutes et revenir dans **Settings → Pages** : GitHub affichera l'adresse du site.

L'adresse sera généralement :
`https://VOTRE-PSEUDO.github.io/mc-digital/`

Remplacez `VOTRE-PSEUDO` par votre nom d'utilisateur GitHub. Ne partagez pas votre mot de passe ni vos codes de connexion.

## Coordonnées incluses
Téléphone : 64 65 19 85  
E-mail : 67510069a@gmail.com  
Adresse : Niamana, Mali

Le bouton WhatsApp utilise le numéro international +223 64 65 19 85.
